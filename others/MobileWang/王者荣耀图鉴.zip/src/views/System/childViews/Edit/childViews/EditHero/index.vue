<script setup lang="ts"></script>

<template>
  <div class="edit-skill"></div>
</template>

<style scoped lang="less">
@import url("./index.less");
</style>
