<script setup lang="ts"></script>

<template>
  <div class="edit-skin"></div>
</template>

<style scoped lang="less">
@import url("./index.less");
</style>
