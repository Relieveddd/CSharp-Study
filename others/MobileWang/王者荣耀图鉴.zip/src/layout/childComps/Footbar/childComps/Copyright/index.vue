<template>
  <a class="copyright" href="https://github.com/lengyibai" target="_blank">@lengyibai</a>
</template>

<style scoped lang="less">
@import url("./index.less");
</style>
