<template>
  <FormLabel v-bind="$attrs">
    <K-Input v-bind="$attrs" width="250px" line color="var(--theme-color-five)" />
  </FormLabel>
</template>
